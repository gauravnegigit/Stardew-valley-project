import os 
import pygame 

def import_folder(path):
    surface_list = []

    for _ , __ , files in os.walk(path):
        for image in files :
            full_path = f'{path}/{image}'
            image_surf = pygame.image.load(full_path).convert_alpha()
            surface_list.append(image_surf)
        
    return surface_list