import pygame
from settings import * 
from pytmx.util_pygame import load_pygame
from support import * 
import random

class SoilTile(pygame.sprite.Sprite):
    def __init__(self , pos , surf , groups) -> None:
        super().__init__(groups)
        self.image = surf 
        self.rect = self.image.get_rect(topleft = pos)
        self.z = LAYERS['soil']

class WaterTile(pygame.sprite.Sprite):
    def __init__(self , pos , surf , groups) -> None:
        super().__init__(groups)
        self.image = surf 
        self.rect = self.image.get_rect(topleft = pos)
        self.z = LAYERS['soil water']

class Plant(pygame.sprite.Sprite):
    def __init__(self , plant_type , groups , soil , check_watered) -> None:
        super().__init__(groups)

        # setup 
        self.plant_type = plant_type
        self.frames = import_folder(f'../graphics/fruit/{plant_type}')
        self.soil = soil 
        self.check_watered = check_watered

        #plant growing 
        self.age = 0 
        self.max_age = len(self.frames) - 1
        self.grow_speed= GROW_SPEED[plant_type]
        self.harvestable = False

        self.image = self.frames[self.age] 
        self.y_offset = -16 if plant_type == 'corn' else -8 
        self.rect = self.image.get_rect(midbottom = soil.rect.midbottom + pygame.math.Vector2(0 , self.y_offset))
        self.z = LAYERS['ground plant']

    def grow(self):
        if self.check_watered(self.rect.center):
            self.age += self.grow_speed

        if int(self.age) > 0 :
            self.z = LAYERS['main']
            self.hitbox = self.rect.copy().inflate(-26 , -self.rect.height * 0.4)
        
        if self.age>= self.max_age :
            self.age = self.max_age 
            self.harvestable = True

        self.image = self.frames[int(self.age)]
        self.rect = self.image.get_rect(midbottom = self.soil.rect.midbottom + pygame.math.Vector2(0 , self.y_offset))
        

class SoilLayer :
    def __init__(self , all_sprites):
        self.all_sprites = all_sprites
        self.soil_sprites = pygame.sprite.Group()
        self.water_sprites = pygame.sprite.Group()
        self.plant_sprites = pygame.sprite.Group()

        #graphics
        self.soil_surf = pygame.image.load('../graphics/soil/o.png')
        self.water_surfs = import_folder('../graphics/soil_water')

        # requirements
        # if the are is farmable
        self.create_soil_grid()
        self.create_hit_rects()

    def create_soil_grid(self):
        ground = pygame.image.load('../graphics/world/ground.png')
        h_tiles , v_tiles = ground.get_width()//TILE_SIZE , ground.get_height()//TILE_SIZE

        self.grid  = [[[] for col in range(h_tiles)] for row in range(v_tiles)]
        for x , y , _ in load_pygame('../data/map.tmx').get_layer_by_name('Farmable').tiles():
            self.grid[y][x].append('F')
        
    def create_hit_rects(self):
        self.hit_rects = []
        for i , row in enumerate(self.grid):
            for j , col in enumerate(row):
                if 'F' in col :
                    x = j * TILE_SIZE
                    y = i * TILE_SIZE
                    rect = pygame.Rect(x , y , TILE_SIZE , TILE_SIZE)
                    self.hit_rects.append(rect)

    def get_hit(self , point):
        for rect in self.hit_rects:
            if rect.collidepoint(point):
                x = rect.x//TILE_SIZE
                y  = rect.y //TILE_SIZE

                if 'F' in self.grid[y][x]:
                    self.grid[y][x].append('X')         # x mark indicating that there is a soil patch there
                    self.create_soil_tiles()

                    if self.raining:
                        self.water_all()
    
    def water(self , target_pos):
        for soil_sprite in self.soil_sprites.sprites():
            if soil_sprite.rect.collidepoint(target_pos):
                self.grid[soil_sprite.rect.y//TILE_SIZE][soil_sprite.rect.x//TILE_SIZE].append('W')

                pos = soil_sprite.rect.topleft
                surf = random.choice(self.water_surfs)
                # print(surf)
                WaterTile(pos , surf , [self.all_sprites , self.water_sprites])

    def water_all(self):
        """
        this function will water all the unwatered soil sprites
        """

        for i , row in enumerate(self.grid):
            for j , cell in enumerate(row):
                if 'X' in cell and 'W' not in cell:
                    cell.append('W')
                    x , y = j * TILE_SIZE , i * TILE_SIZE
                    WaterTile((x , y) , random.choice(self.water_surfs) , [self.all_sprites  , self.water_sprites] )

    def remove_water(self):
        for sprite in self.water_sprites.sprites():
            sprite.kill()
        
        for row in self.grid :
            for cell in row :
                if 'W' in cell :
                    cell.remove('W')
    
    def check_watered(self , pos):
        x = pos[0] // TILE_SIZE
        y = pos[1] // TILE_SIZE
        cell = self.grid[y][x]
        is_watered = 'W' in cell
        return is_watered


    def plant_seed(self , target_pos , seed):
        for soil_sprite in self.soil_sprites.sprites():
            if soil_sprite.rect.collidepoint(target_pos):
                x , y  = soil_sprite.rect.x //TILE_SIZE  , soil_sprite.rect.y //TILE_SIZE

                if 'P' not in self.grid[y][x]:
                    self.grid[y][x].append('P')
                    Plant(seed , [self.all_sprites , self.plant_sprites] , soil_sprite , self.check_watered)

    def update_plants(self):
        for plant in self.plant_sprites.sprites():
            plant.grow()

    def create_soil_tiles(self):
        self.soil_sprites.empty()
        for i , row in enumerate(self.grid):
            for j , cell in enumerate(row):
                if 'X' in cell :
                    SoilTile(
                        pos = (j * TILE_SIZE ,i * TILE_SIZE ),
                        surf = self.soil_surf , 
                        groups = [self.all_sprites , self.soil_sprites]
                    )