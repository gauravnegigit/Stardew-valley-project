import random
from timer import Timer 
import pygame 
from settings import * 

class Generic(pygame.sprite.Sprite):
	def __init__(self, pos , surf , groups , z = LAYERS['main']  , inflate = (0.3 , 0.8)) -> None:
		super().__init__(groups)
		self.image = surf 
		self.rect = self.image.get_rect(topleft = pos)   # setting the rect from the topleft corner of the surface 
		self.z = z
		self.hitbox = self.rect.copy().inflate(-self.rect.width*inflate[0] , -self.rect.height * inflate[1])
	
class Regular(Generic):
	def __init__(self, pos, size, groups, name) -> None:
		surf = pygame.Surface(size)
		super().__init__(pos, surf, groups)
		self.name = name 

class Water(Generic):
	def __init__(self, pos, frames , groups) -> None:
		# naimation setup 

		self.frames = frames
		self.frame_index = 0 

		# sprite setup
		super().__init__(
			pos = pos ,
			surf = self.frames[self.frame_index],
			groups = groups,
			z = LAYERS['water']
		)
	
	def animate(self , dt):
		self.frame_index += 5 * dt 
		if self.frame_index >= len(self.frames):
			self.frame_index = 0 
		self.image = self.frames[int(self.frame_index)]
	
	def update(self , dt):
		self.animate(dt)

class WildFlower(Generic):
	def __init__(self , pos , surf , groups):
		super().__init__(pos , surf , groups)
		self.hitbox = self.rect.copy().inflate(-20 , -self.rect.height * 0.9)

class Particle(Generic):
	def __init__(self, pos, surf, groups, z , duration = 200) -> None:
		super().__init__(pos, surf, groups, z)
		self.start_time = pygame.time.get_ticks()
		self.duration = duration

		# white surface 
		mask = pygame.mask.from_surface(self.image)
		new_surf = mask.to_surface()
		new_surf.set_colorkey((0 , 0, 0)) # settings the color of the particles according to the shape of the collided 
		self.image = new_surf 
	
	def update(self , dt):
		current_time = pygame.time.get_ticks()
		if current_time - self.start_time > self.duration :
			self.kill()

class Tree(Generic):
	def __init__(self , pos , surf , groups , name , func):
		super().__init__(pos , surf , groups)

		# setting off tree attributes 
		self.health  = 5
		self.alive = True 
		path = f'../graphics/stumps/{"small" if name == "Small" else "large"}.png'
		self.stump_surf = pygame.image.load(path)
		self.invul_timer = Timer(200)

		# apples
		self.apple_surf = pygame.image.load('../graphics/fruit/apple.png')
		self.apple_pos = APPLE_POS[name]
		self.apple_sprites = pygame.sprite.Group()
		self.create_fruit()

		self.add_items = func
	
	def create_fruit(self):
		for pos in self.apple_pos:
			if random.randint(0,10) < 2:
				x = pos[0] + self.rect.left
				y = pos[1] + self.rect.top
				Generic(
					pos = (x,y), 
					surf = self.apple_surf, 
					groups = [self.apple_sprites,self.groups()[0]],
					z = LAYERS['fruit'])

	def damage(self):

		self.health -= 1

		# remove an apple
		if len(self.apple_sprites.sprites()) > 0 :
			random_apple = random.choice(self.apple_sprites.sprites())
			Particle(
				pos = random_apple.rect.topleft , # setting the partile pos ate the topleft of apple's pos
				surf = random_apple.image , 
				groups = self.groups()[0] , 
				z = LAYERS['fruit'] 
			)
			self.add_items('apple')
			random_apple.kill()
		
	def check_death(self):
		"""
		this function comes in handy in removing the tree sprites when its health is gone"""

		if self.health <= 0 :
			Particle(self.rect.topleft , self.image , self.groups()[0] , LAYERS['fruit'] , 300)
			self.image = self.stump_surf
			self.rect = self.image.get_rect(midbottom = self.rect.midbottom)
			self.hitbox = self.rect.copy().inflate(-10 , - self.rect.height * 0.58)
			self.alive = False
			self.add_items('wood')
	
	def update(self , dt):
		if self.alive : 
			self.check_death()