<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Plant Decoration" tilewidth="64" tileheight="64" tilecount="10" columns="5">
 <image source="../../graphics/environment/Plant Decoration.png" width="320" height="128"/>
</tileset>
